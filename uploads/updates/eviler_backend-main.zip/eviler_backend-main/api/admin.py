from django.contrib import admin
from .models import *


admin.site.register(Module)
admin.site.register(ActiveModule)
admin.site.register(ActiveModulesGroup)
admin.site.register(CustomUser)
admin.site.register(ImageModel)
admin.site.register(News)
# Register your models here.
